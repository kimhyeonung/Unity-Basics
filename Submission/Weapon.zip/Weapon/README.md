# Threadloom

FWeapon 수업 구조를 확장한 실뜨기 무기입니다.

- Threadloom/ProjectileControllerThreadloom.cs: ProjectileController 상속, 직조 전진 → 공전 → 발사 지점 귀환, 풀 재사용.
- Threadloom/FirePattern_Weave.cs: IFirePattern 구현, 대칭 바늘 5발을 시간차 발사.
- Threadloom/ThreadloomDefinition.cs: WeaponDefinition 상속, 궤적을 데이터로 설정.
- Threadloom/ThreadloomArena.cs: 조준·입력·연사 간격 및 표적 관리.
- WeaponController: 기존 메서드 유지, FirePatternType에 Weave=3 등록만 추가.
- FirePatternFactory: 새 패턴 등록 한 줄 추가.
- Support/: 제공 프로젝트의 플레이어·적·HP·화면 경계 등 지원 스크립트.
- Editor/: 완성 씬·프리팹·무기 데이터 생성, 자동 Play 검증 및 영상 녹화.

WeaponDefinition 데이터 구성:
THREADLOOM = 새 바늘 투사체 + 새 Weave 패턴 / 5발 / 피해 18 / 속도 8 / 거리 6.2 / 간격 1.05초.
NEEDLE BURST = 새 바늘 투사체 + 기존 Burst 패턴 / 3발 / 피해 22 / 속도 10 / 거리 7 / 간격 0.85초.
PRISM FAN = 기존 기본 투사체 + 기존 Spread 패턴 / 5발 / 피해 16 / 속도 9 / 간격 0.45초.

무기 데이터·프리팹과 완성 씬은 실제 프로젝트의 Assets/Threadloom 및 Assets/Scenes/Threadloom.unity에 저장되어 있습니다.
이 ZIP은 과제 지시에 맞춘 스크립트 폴더 제출물입니다. 제공 프로젝트의 기본 리소스를 전제로 하며, 단독 Unity 프로젝트 압축 파일은 아닙니다.
